Paste this in
C:\Users\MAC\AppData\Roaming\Playnite\Themes\Fullscreen

*install ps5ish original skin from playnite first

*in case it does't work paste the insides of my ps5ish skin contents to the original ps5ish skin

*To change the profile picture replace the Media/ProfilePicture.png with any image (prefered 72x72 px in png formate) and name it ProfilePicture 

